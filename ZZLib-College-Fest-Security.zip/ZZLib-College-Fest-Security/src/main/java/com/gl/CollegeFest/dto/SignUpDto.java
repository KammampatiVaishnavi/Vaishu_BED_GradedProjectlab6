
package com.gl.CollegeFest.dto;

import lombok.Data;

@Data
public class SignUpDto {
	private String name;
	private String username;
	private String eamil;
	private String password;

	/**
	 * @return
	 */
	public String getname() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 */
	public String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 */
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 */
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 */

}
