
package com.gl.CollegeFest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.CollegeFest.entity.student;

public interface StudentRepository extends JpaRepository<student, Integer>{


}