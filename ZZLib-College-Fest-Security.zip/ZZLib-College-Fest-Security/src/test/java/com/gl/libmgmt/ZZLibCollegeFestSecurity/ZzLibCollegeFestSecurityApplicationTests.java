package com.gl.libmgmt.ZZLibCollegeFestSecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZzLibCollegeFestSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
